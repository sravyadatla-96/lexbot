import json
import requests
import urllib3
import time

# Cache dictionary to store API responses
cache = {}
# Time-to-live for cached entries (adjust as needed)
CACHE_TTL = 300  # 5 minutes


def get_api_data():
    if 'data' in cache and 'timestamp' in cache:
        current_time = time.time()
        # Check if the cached data is still valid (within TTL)
        if current_time - cache['timestamp'] < CACHE_TTL:
            return cache['data']

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.59'
    }

    # Disable SSL verification
    urllib3.disable_warnings()

    # Make the request with SSL verification disabled
    response = requests.get('https://dummy.restapiexample.com/api/v1/employees', headers=headers, verify=False)
    data = response.json()

    # Update the cache with the new data and current timestamp
    cache['data'] = data
    cache['timestamp'] = time.time()

    return data


def lambda_handler(event, context):
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']

    # Extract the employee ID and info type from the Lex slots
    employee_id = slots['EmpID']['value']['originalValue']
    info_type = slots['InfoType']['value']['originalValue']

    # Print the input received from Lex
    print("Input from Lex:")
    print("Employee ID:", employee_id)
    print("Info Type:", info_type)

    try:
        data = get_api_data()
        print("API Response:")
        print(data)  # Print API response
    except Exception as e:
        response_content = "Error fetching API data: " + str(e)
    else:
        # Check if the employee ID is present in the API response
        if 'status' in data and data['status'] == 'success':
            employee_info = None
            for employee in data['data']:
                if str(employee['id']) == employee_id:
                    if info_type.lower() in employee:
                        employee_info = employee[info_type.lower()]
                        break
            if employee_info:
                response_content = f"The {info_type} of employee ID {employee_id} is: {employee_info}"
            else:
                response_content = f"No information available for the requested InfoType: {info_type}"
        else:
            response_content = "Unable to retrieve employee information"

    # Check if the employee ID is not present in the API data
    if 'data' in data and not any(str(employee['id']) == employee_id for employee in data['data']):
        response_content = f"Employee ID {employee_id} is not present in the API"

    # Prepare the response for Lex
    response = {
        "sessionState": {
            "dialogAction": {
                "type": "Close"
            },
            "intent": {
                'name': intent,
                'slots': slots,
                'state': 'Fulfilled'
            }
        },
        "messages": [
            {
                "contentType": "PlainText",
                "content": response_content
            }
        ]
    }

    # Print the output going to Lex
    print("Output to Lex:")
    print(response)

    return response


# Test the lambda_handler
event_data = {
    'sessionState': {
        'intent': {
            'name': 'RetriveAPIInfo',
            'slots': {
                'EmpID': {
                    'value': {
                        'originalValue': '5'
                    }
                },
                'InfoType': {
                    'value': {
                        'originalValue': 'employee_age'
                    }
                }
            }
        }
    }
}

response = lambda_handler(event_data, None)
print(json.dumps(response, indent=4))
