import pymysql
import json

def get_employee_count(dept_name):
    # Connect to the MySQL server
    cnx = pymysql.connect(
        host='rdsdatabase.clp20xsfpbvu.ap-southeast-1.rds.amazonaws.com',
        user='randomuser', 
        password='Nadimpalli345',
        database='RDS_TEST'
    )

    # Create a cursor object
    cursor = cnx.cursor()

    # Prepare the SQL query
    query = "SELECT emp_count FROM Department WHERE dept_name = %s"

    # Execute the query
    cursor.execute(query, (dept_name,))

    # Fetch the result
    result = cursor.fetchone()

    # Close the cursor and connection
    cursor.close()
    cnx.close()

    # Check if the result is available
    if result is not None:
        emp_count = result[0]
        return emp_count 
    else:
        return None


def lambda_handler(event, context):
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']

    # Extract the value of DeptName from the event
    dept_name = slots['DeptName']['value']['originalValue']

    print(f"Input from Lex: {dept_name}")

    # Call the function to get the employee count
    emp_count = get_employee_count(dept_name)

    if emp_count is not None:
       response = {
                "sessionState": {
                    "dialogAction": { 
                        "type": "Close"
                    },
                    "intent": {
                        'name': intent,
                        'slots': slots,
                        'state': 'Fulfilled'
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": f"The employee count for {dept_name} is: {emp_count}"
                    } 
                ]
            }
    else:
        response = {
                "sessionState": {
                    "dialogAction": { 
                        "type": "Close"
                    },
                    "intent": {
                        'name': intent,
                        'slots': slots,
                        'state': 'Fulfilled'
                    }
                },
                "messages": [
                    {
                        "contentType": "PlainText",
                        "content": f"No data found for the department {dept_name}"
                    } 
                ]
            }

    


    # Return the response to Lex
    return response


def test_handler():
    # Simulate a test event
    event = {
        'sessionState': {
            'intent': {
                'name': 'MysqlInstance',
                'slots': {
                    'DeptName': {
                        'value': {
                            'originalValue': 'Innovation',
                            'resolvedValues': ['Innovation'],
                            'interpretedValue': 'Innovation'
                        },
                        'resolutions': [],
                        'shape': 'ScalarValue'
                    }
                }
            }
        }
    }

    # Call the lambda_handler
    response = lambda_handler(event, None)
    print(json.dumps(response, indent=4))

test_handler()
